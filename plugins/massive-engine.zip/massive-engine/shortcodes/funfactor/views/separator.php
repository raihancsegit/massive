<div class="fun-factor">
    <div class="icon"><i class="<?php echo esc_attr($atts['icon']);?>"></i></div>
    <div class="fun-info">
        <h1 class="timer" data-from="0" data-to="<?php echo esc_attr($atts['value']);?>" data-speed="1000"></h1>
        <span><?php echo wp_kses_post($atts['text']);?></span>
    </div>
</div>
