<a class="client-item" href="<?php echo esc_url( $atts['url'] ); ?>">
    <img src="<?php echo esc_url( $image ); ?>" >
</a>


