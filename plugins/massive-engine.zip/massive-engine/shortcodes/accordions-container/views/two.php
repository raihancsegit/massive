<?php $toggle = $atts['toggle'] ; ?>
<dl class="<?php echo ( ( 'true' === $toggle ) ? 'toggle' : 'accordion' ); ?> <?php echo esc_attr( $atts['uid'] ); ?>">
    <?php echo do_shortcode( $content ); ?>
</dl>
