 <div id="testimonial-2" class="testimonials outer-border <?php echo esc_attr( $atts['uid'] ); ?>">
    <?php echo do_shortcode( $content ); ?>
 </div>
