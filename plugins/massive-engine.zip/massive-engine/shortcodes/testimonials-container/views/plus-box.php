<ul class="testimonial plus-box grid-2 <?php echo esc_attr( $atts['uid'] ); ?>">
    <?php echo do_shortcode( $content ); ?>
</ul>
