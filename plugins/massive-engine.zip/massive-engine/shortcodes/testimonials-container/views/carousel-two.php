 <div id="testimonial-3" class="testimonials text-center big-icon <?php echo esc_attr( $atts['uid'] ); ?>">
    <?php echo do_shortcode( $content ); ?>
 </div>
