 <div id="testimonial-4" class="testimonials testimonial-alt <?php echo esc_attr( $atts['uid'] ); ?>">
    <?php echo do_shortcode( $content ); ?>
 </div>
