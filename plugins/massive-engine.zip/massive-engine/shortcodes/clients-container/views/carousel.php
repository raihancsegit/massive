<div class="carousel-client" data-autoplay="<?php echo esc_attr( $atts['autoplay'] ); ?>" data-item="<?php echo esc_attr( $atts['items'] ); ?>" data-pagination="<?php echo esc_attr( $atts['pagination'] ); ?>">
    <?php echo do_shortcode( $content );  ?>
</div>

